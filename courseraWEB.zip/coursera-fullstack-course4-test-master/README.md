# coursera-fullstack-course4-test
My solutions to the programming assignments of [Coursera course "HTML, CSS, and Javascript for Web Developers"]( https://www.coursera.org/learn/html-css-javascript-for-web-developers/home)
